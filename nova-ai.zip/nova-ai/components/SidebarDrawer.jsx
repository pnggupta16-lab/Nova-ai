import React, { useRef, useEffect } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  Animated, Dimensions, FlatList, Pressable,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { useApp } from '../hooks/useAppStore';
import { Colors } from '../constants/theme';

const { width } = Dimensions.get('window');
const SIDEBAR_W = 260;

export default function SidebarDrawer({ open, onClose }) {
  const router = useRouter();
  const { sessions, activeSessionId, setActiveSessionId, newSession } = useApp();
  const slideAnim = useRef(new Animated.Value(-SIDEBAR_W)).current;
  const overlayAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.spring(slideAnim, {
        toValue: open ? 0 : -SIDEBAR_W,
        tension: 80, friction: 14,
        useNativeDriver: true,
      }),
      Animated.timing(overlayAnim, {
        toValue: open ? 1 : 0,
        duration: 250,
        useNativeDriver: true,
      }),
    ]).start();
  }, [open]);

  const handleNewSession = () => {
    newSession();
    onClose();
  };

  const handleSelectSession = (id) => {
    setActiveSessionId(id);
    onClose();
  };

  return (
    <>
      {/* Overlay */}
      <Animated.View
        pointerEvents={open ? 'auto' : 'none'}
        style={[styles.overlay, { opacity: overlayAnim }]}
      >
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} />
      </Animated.View>

      {/* Drawer */}
      <Animated.View style={[styles.drawer, { transform: [{ translateX: slideAnim }] }]}>
        {/* Header */}
        <LinearGradient
          colors={['rgba(0,212,255,0.08)', 'transparent']}
          style={styles.drawerHeader}
        >
          <View>
            <Text style={styles.logoText}>NOVA AI</Text>
            <Text style={styles.logoSub}>Neural Assistant v4.2</Text>
          </View>
          <TouchableOpacity style={styles.closeBtn} onPress={onClose}>
            <Text style={styles.closeBtnText}>✕</Text>
          </TouchableOpacity>
        </LinearGradient>

        {/* New chat */}
        <TouchableOpacity style={styles.newChatBtn} onPress={handleNewSession} activeOpacity={0.8}>
          <LinearGradient
            colors={['rgba(0,102,255,0.2)', 'rgba(0,212,255,0.08)']}
            start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
            style={styles.newChatGrad}
          >
            <Text style={styles.newChatText}>+ NEW SESSION</Text>
          </LinearGradient>
        </TouchableOpacity>

        {/* Sessions */}
        <Text style={styles.sectionLabel}>Recent Sessions</Text>
        <FlatList
          data={sessions}
          keyExtractor={s => s.id}
          contentContainerStyle={{ gap: 2 }}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={[styles.sessionItem, item.id === activeSessionId && styles.sessionItemActive]}
              onPress={() => handleSelectSession(item.id)}
              activeOpacity={0.7}
            >
              <Text style={styles.sessionTitle} numberOfLines={1}>{item.title}</Text>
              <Text style={styles.sessionTime}>{item.time}</Text>
            </TouchableOpacity>
          )}
          showsVerticalScrollIndicator={false}
          style={{ flex: 1 }}
        />

        {/* Footer */}
        <View style={styles.drawerFooter}>
          <TouchableOpacity
            style={styles.footerBtn}
            onPress={() => { onClose(); router.push('/settings'); }}
          >
            <Text style={styles.footerBtnText}>⚙  Settings</Text>
          </TouchableOpacity>
        </View>
      </Animated.View>
    </>
  );
}

const styles = StyleSheet.create({
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(3,7,18,0.7)',
    zIndex: 10,
  },
  drawer: {
    position: 'absolute',
    top: 0, bottom: 0, left: 0,
    width: SIDEBAR_W,
    backgroundColor: Colors.panel,
    borderRightWidth: 1,
    borderRightColor: Colors.border,
    zIndex: 20,
    flexDirection: 'column',
  },

  drawerHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    paddingTop: 50,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  logoText: {
    fontFamily: 'Orbitron',
    fontSize: 16,
    fontWeight: '900',
    letterSpacing: 3,
    color: Colors.cyan,
  },
  logoSub: {
    fontFamily: 'Rajdhani',
    fontSize: 10,
    color: Colors.textMuted,
    letterSpacing: 1,
    marginTop: 2,
  },
  closeBtn: {
    width: 30, height: 30,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: 'center', justifyContent: 'center',
  },
  closeBtnText: { color: Colors.textMuted, fontSize: 14 },

  newChatBtn: {
    margin: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'rgba(0,212,255,0.3)',
    overflow: 'hidden',
  },
  newChatGrad: { padding: 10, alignItems: 'center' },
  newChatText: {
    fontFamily: 'Orbitron',
    fontSize: 11,
    fontWeight: '700',
    color: Colors.cyan,
    letterSpacing: 1.5,
  },

  sectionLabel: {
    fontFamily: 'Rajdhani',
    fontSize: 10,
    color: Colors.textMuted,
    letterSpacing: 2,
    textTransform: 'uppercase',
    paddingHorizontal: 14,
    paddingBottom: 6,
  },

  sessionItem: {
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 6,
    marginHorizontal: 6,
    borderWidth: 1,
    borderColor: 'transparent',
  },
  sessionItemActive: {
    backgroundColor: 'rgba(0,102,255,0.1)',
    borderColor: 'rgba(0,102,255,0.3)',
  },
  sessionTitle: {
    fontFamily: 'Rajdhani',
    fontSize: 13,
    color: Colors.text,
    fontWeight: '500',
  },
  sessionTime: {
    fontFamily: 'Rajdhani',
    fontSize: 11,
    color: Colors.textMuted,
    marginTop: 2,
  },

  drawerFooter: {
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    padding: 12,
  },
  footerBtn: {
    padding: 10,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: 'center',
  },
  footerBtnText: {
    fontFamily: 'Rajdhani',
    fontSize: 13,
    color: Colors.textMuted,
    fontWeight: '600',
    letterSpacing: 1,
  },
});
