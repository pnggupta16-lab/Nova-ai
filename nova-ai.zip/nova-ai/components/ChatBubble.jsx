import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors } from '../constants/theme';

export default function ChatBubble({ message }) {
  const isNova = message.role === 'nova';
  const slideAnim = useRef(new Animated.Value(0)).current;
  const opacityAnim = useRef(new Animated.Value(0)).current;
  const [displayText, setDisplayText] = useState(isNova ? '' : message.text);
  const [showCursor, setShowCursor] = useState(isNova);

  // Entrance animation
  useEffect(() => {
    Animated.parallel([
      Animated.spring(slideAnim, { toValue: 1, tension: 60, friction: 10, useNativeDriver: true }),
      Animated.timing(opacityAnim, { toValue: 1, duration: 200, useNativeDriver: true }),
    ]).start();
  }, []);

  // Streaming typewriter for NOVA messages
  useEffect(() => {
    if (!isNova) return;
    let i = 0;
    const full = message.text;
    const timer = setInterval(() => {
      if (i <= full.length) {
        setDisplayText(full.slice(0, i));
        i++;
      } else {
        clearInterval(timer);
        setShowCursor(false);
      }
    }, 18);
    return () => clearInterval(timer);
  }, [message.text]);

  const translateY = slideAnim.interpolate({ inputRange: [0, 1], outputRange: [12, 0] });
  const translateX = slideAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [isNova ? -8 : 8, 0],
  });

  return (
    <Animated.View
      style={[
        styles.wrapper,
        isNova ? styles.wrapperNova : styles.wrapperUser,
        { opacity: opacityAnim, transform: [{ translateY }, { translateX }] },
      ]}
    >
      <Text style={[styles.sender, isNova ? styles.senderNova : styles.senderUser]}>
        {isNova ? 'NOVA AI' : 'YOU'}
      </Text>

      {isNova ? (
        <View style={styles.novaBubble}>
          {/* Top accent line */}
          <LinearGradient
            colors={[Colors.cyan, 'transparent']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={styles.accentLine}
          />
          <Text style={styles.novaText}>
            {displayText}
            {showCursor && <Text style={styles.cursor}>|</Text>}
          </Text>
        </View>
      ) : (
        <LinearGradient
          colors={['rgba(0,102,255,0.25)', 'rgba(124,58,237,0.15)']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.userBubble}
        >
          <Text style={styles.userText}>{displayText}</Text>
        </LinearGradient>
      )}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  wrapper: { maxWidth: '85%' },
  wrapperNova: { alignSelf: 'flex-start' },
  wrapperUser: { alignSelf: 'flex-end', alignItems: 'flex-end' },

  sender: {
    fontSize: 10,
    letterSpacing: 1.5,
    fontFamily: 'Rajdhani',
    fontWeight: '700',
    marginBottom: 4,
  },
  senderNova: { color: Colors.cyan },
  senderUser: { color: Colors.blue },

  novaBubble: {
    backgroundColor: 'rgba(0,212,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(0,212,255,0.18)',
    borderRadius: 12,
    borderTopLeftRadius: 3,
    padding: 12,
    overflow: 'hidden',
  },
  accentLine: {
    position: 'absolute',
    top: 0, left: 0, right: 0,
    height: 1,
    opacity: 0.5,
  },
  novaText: {
    fontFamily: 'Rajdhani',
    fontSize: 15,
    color: Colors.text,
    lineHeight: 22,
    letterSpacing: 0.3,
    fontWeight: '400',
  },
  cursor: {
    color: Colors.cyan,
    fontWeight: '300',
  },

  userBubble: {
    borderWidth: 1,
    borderColor: 'rgba(0,102,255,0.3)',
    borderRadius: 12,
    borderBottomRightRadius: 3,
    padding: 12,
  },
  userText: {
    fontFamily: 'Rajdhani',
    fontSize: 15,
    color: Colors.text,
    lineHeight: 22,
    letterSpacing: 0.3,
    fontWeight: '400',
  },
});
