import React, { useEffect, useRef } from 'react';
import { View, StyleSheet, Animated, Easing } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors } from '../constants/theme';

export default function NovaOrb({ state = 'idle' }) {
  const breathe = useRef(new Animated.Value(1)).current;
  const ring1Rot = useRef(new Animated.Value(0)).current;
  const ring2Rot = useRef(new Animated.Value(0)).current;
  const ring3Rot = useRef(new Animated.Value(0)).current;
  const glowAnim = useRef(new Animated.Value(0)).current;

  // Ring rotations
  useEffect(() => {
    const r1 = Animated.loop(
      Animated.timing(ring1Rot, { toValue: 1, duration: 6000, easing: Easing.linear, useNativeDriver: true })
    );
    const r2 = Animated.loop(
      Animated.timing(ring2Rot, { toValue: 1, duration: 4000, easing: Easing.linear, useNativeDriver: true })
    );
    const r3 = Animated.loop(
      Animated.timing(ring3Rot, { toValue: 1, duration: 3000, easing: Easing.linear, useNativeDriver: true })
    );
    r1.start(); r2.start(); r3.start();
    return () => { r1.stop(); r2.stop(); r3.stop(); };
  }, []);

  // State-based orb animation
  useEffect(() => {
    let anim;
    if (state === 'idle') {
      anim = Animated.loop(
        Animated.sequence([
          Animated.timing(breathe, { toValue: 1.06, duration: 2000, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
          Animated.timing(breathe, { toValue: 0.95, duration: 2000, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
        ])
      );
      Animated.timing(glowAnim, { toValue: 0, duration: 400, useNativeDriver: false }).start();
    } else if (state === 'speaking') {
      anim = Animated.loop(
        Animated.sequence([
          Animated.timing(breathe, { toValue: 1.15, duration: 280, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
          Animated.timing(breathe, { toValue: 0.95, duration: 280, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
        ])
      );
      Animated.timing(glowAnim, { toValue: 1, duration: 400, useNativeDriver: false }).start();
    } else if (state === 'listening') {
      anim = Animated.loop(
        Animated.sequence([
          Animated.timing(breathe, { toValue: 1.2, duration: 500, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
          Animated.timing(breathe, { toValue: 1.0, duration: 500, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
        ])
      );
      Animated.timing(glowAnim, { toValue: 2, duration: 400, useNativeDriver: false }).start();
    }
    anim?.start();
    return () => anim?.stop();
  }, [state]);

  const ring1Deg = ring1Rot.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });
  const ring2Deg = ring2Rot.interpolate({ inputRange: [0, 1], outputRange: ['360deg', '0deg'] });
  const ring3Deg = ring3Rot.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });

  const glowColor = glowAnim.interpolate({
    inputRange: [0, 1, 2],
    outputRange: [
      'rgba(0,212,255,0.2)',
      'rgba(0,102,255,0.5)',
      'rgba(0,255,136,0.5)',
    ],
  });

  const orbColors = state === 'listening'
    ? ['#00ff88', '#00d4ff', '#0066ff']
    : ['#00d4ff', '#0066ff', '#7c3aed'];

  return (
    <View style={styles.container}>
      {/* Outer glow */}
      <Animated.View style={[styles.glowRing, { backgroundColor: glowColor, borderColor: glowColor }]} />

      {/* Rings */}
      <Animated.View style={[styles.ring, styles.ring1, { transform: [{ rotate: ring1Deg }] }]}>
        <View style={styles.ringDot} />
      </Animated.View>
      <Animated.View style={[styles.ring, styles.ring2, { transform: [{ rotate: ring2Deg }] }]}>
        <View style={[styles.ringDot, styles.ringDot2]} />
      </Animated.View>
      <Animated.View style={[styles.ring, styles.ring3, { transform: [{ rotate: ring3Deg }] }]}>
        <View style={[styles.ringDot, styles.ringDot3]} />
      </Animated.View>

      {/* Core */}
      <Animated.View style={[styles.core, { transform: [{ scale: breathe }] }]}>
        <LinearGradient
          colors={orbColors}
          start={{ x: 0.2, y: 0.2 }}
          end={{ x: 0.8, y: 0.8 }}
          style={styles.coreGradient}
        />
        {/* Inner shine */}
        <View style={styles.coreShine} />
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: 130, height: 130,
    alignItems: 'center',
    justifyContent: 'center',
  },
  glowRing: {
    position: 'absolute',
    width: 100, height: 100,
    borderRadius: 50,
    opacity: 0.15,
  },
  ring: {
    position: 'absolute',
    borderRadius: 999,
    borderWidth: 1,
    alignItems: 'flex-start',
    justifyContent: 'center',
  },
  ring1: {
    width: 128, height: 128,
    borderColor: 'rgba(0,212,255,0.25)',
  },
  ring2: {
    width: 106, height: 106,
    borderColor: 'rgba(0,102,255,0.3)',
  },
  ring3: {
    width: 84, height: 84,
    borderColor: 'rgba(124,58,237,0.25)',
  },
  ringDot: {
    width: 5, height: 5,
    borderRadius: 3,
    backgroundColor: Colors.cyan,
    marginLeft: -2,
    shadowColor: Colors.cyan,
    shadowOpacity: 0.8,
    shadowRadius: 4,
    elevation: 4,
  },
  ringDot2: { backgroundColor: Colors.blue, shadowColor: Colors.blue },
  ringDot3: { backgroundColor: Colors.purple, shadowColor: Colors.purple },

  core: {
    width: 64, height: 64,
    borderRadius: 32,
    overflow: 'hidden',
    shadowColor: Colors.cyan,
    shadowOpacity: 0.6,
    shadowRadius: 16,
    elevation: 16,
  },
  coreGradient: { ...StyleSheet.absoluteFillObject },
  coreShine: {
    position: 'absolute',
    top: 8, left: 10,
    width: 20, height: 20,
    borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
});
