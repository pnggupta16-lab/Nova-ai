import React, { createContext, useContext, useState, useCallback } from 'react';
import { Personalities } from '../constants/theme';

const AppContext = createContext(null);

let msgId = 0;

export function AppProvider({ children }) {
  const [sessions, setSessions] = useState([
    { id: 's1', title: 'System initialization', time: 'Just now', messages: [] },
    { id: 's2', title: 'Quantum computing deep dive', time: '2h ago', messages: [] },
    { id: 's3', title: 'Neural network debug session', time: 'Yesterday', messages: [] },
    { id: 's4', title: 'AI research briefing', time: '2 days ago', messages: [] },
  ]);
  const [activeSessionId, setActiveSessionId] = useState('s1');
  const [personality, setPersonality] = useState(Personalities[0]);
  const [mode, setMode] = useState('assistant');
  const [orbState, setOrbState] = useState('idle'); // idle | listening | speaking
  const [isTyping, setIsTyping] = useState(false);

  const activeSession = sessions.find(s => s.id === activeSessionId);

  const addMessage = useCallback((sessionId, role, text) => {
    setSessions(prev => prev.map(s =>
      s.id === sessionId
        ? { ...s, messages: [...s.messages, { id: ++msgId, role, text, ts: Date.now() }] }
        : s
    ));
  }, []);

  const newSession = useCallback(() => {
    const id = 's' + Date.now();
    setSessions(prev => [
      { id, title: 'New session', time: 'Just now', messages: [] },
      ...prev,
    ]);
    setActiveSessionId(id);
  }, []);

  const getResponse = useCallback(() => {
    const pool = personality.responses;
    return pool[Math.floor(Math.random() * pool.length)];
  }, [personality]);

  return (
    <AppContext.Provider value={{
      sessions, activeSessionId, setActiveSessionId,
      activeSession, addMessage, newSession,
      personality, setPersonality,
      mode, setMode,
      orbState, setOrbState,
      isTyping, setIsTyping,
      getResponse,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export const useApp = () => useContext(AppContext);
