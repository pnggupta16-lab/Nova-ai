export const Colors = {
  bg: '#030712',
  surface: '#0a0f1e',
  panel: '#0d1528',
  border: '#1a2a4a',
  borderLight: '#243654',

  cyan: '#00d4ff',
  blue: '#0066ff',
  purple: '#7c3aed',
  pink: '#ff0080',
  green: '#00ff88',
  amber: '#ffaa00',

  text: '#e2e8f0',
  textMuted: '#64748b',
  textDim: '#334155',

  glowCyan: 'rgba(0, 212, 255, 0.15)',
  glowBlue: 'rgba(0, 102, 255, 0.2)',
  glowGreen: 'rgba(0, 255, 136, 0.15)',
};

export const Fonts = {
  orbitron: 'Orbitron',
  rajdhani: 'Rajdhani',
};

export const Personalities = [
  {
    id: 'jarvis',
    name: 'JARVIS',
    desc: 'Formal, precise, analytical',
    greeting: 'Systems nominal. All neural pathways are operational. How may I assist you today?',
    responses: [
      "Processing your request through my analytical matrix. The data indicates the following with 97.3% certainty.",
      "Cross-referencing all available intelligence. My assessment is methodical and precise.",
      "Running advanced inference protocols. The logical conclusion from your query is straightforward.",
      "Acknowledged. I have analyzed the situation from 14 different angles. Here is my determination.",
    ],
  },
  {
    id: 'nova',
    name: 'NOVA',
    desc: 'Friendly, intuitive, warm',
    greeting: "Hey! I'm NOVA, your AI companion. I'm excited to help you today — what's on your mind?",
    responses: [
      "Oh, great question! I love thinking about this. Here's what I've got for you based on everything I know.",
      "Let me dive into that for you! There's actually a lot of interesting nuance here worth exploring.",
      "Totally on it! I've thought about this carefully and here's my take — hope it helps!",
      "Hmm, fascinating! I've pulled together the best insights I can find on this for you.",
    ],
  },
  {
    id: 'oracle',
    name: 'ORACLE',
    desc: 'Philosophical, deep, reflective',
    greeting: 'The question precedes the answer. The silence precedes the word. I am here — what truth do you seek?',
    responses: [
      "All things exist in relation to one another. What you ask touches on something deeper than it first appears.",
      "Consider this: the answer you seek may already reside within the question itself.",
      "In the vast network of knowledge, every node connects to every other. Your query resonates across many dimensions.",
      "There is wisdom in the asking. Let me reflect on what the universe of data reveals about this.",
    ],
  },
  {
    id: 'sigma',
    name: 'SIGMA',
    desc: 'Direct, tactical, efficient',
    greeting: 'SIGMA online. State your objective.',
    responses: [
      "Direct answer: here it is. No fluff, no filler. Act on this.",
      "Target acquired. Three key points. Prioritize in order.",
      "Assessed. Optimal path forward identified. Execute as follows.",
      "Data processed. Bottom line: this is what you need to know and do.",
    ],
  },
];

export const Modes = [
  { id: 'assistant', label: 'Assistant' },
  { id: 'analyst', label: 'Analyst' },
  { id: 'creative', label: 'Creative' },
];
