# NOVA AI — Futuristic Android AI Assistant

A full-featured AI assistant app built with **React Native + Expo**, optimized for Android.

---

## ✨ Features

- **Voice Greeting** — NOVA speaks on app open: *"Welcome back. NOVA AI is online."*
- **Mic Button** — Tap to speak, orb reacts with listening animation
- **Keyboard Input** — Full text chat with multiline support
- **AI Voice Replies** — Text-to-speech via `expo-speech`
- **Streaming Chat** — Typewriter animation on NOVA's responses
- **Animated Orb** — 3-ring glowing orb reacts to idle / listening / speaking
- **Sidebar Drawer** — Slide-in chat history with session switching
- **Settings Screen** — Personality modes + preference toggles
- **4 Personality Modes** — JARVIS, NOVA, ORACLE, SIGMA
- **Cyberpunk Dark UI** — Orbitron + Rajdhani fonts, neon accents

---

## 🚀 Quick Start

### 1. Install dependencies

```bash
npm install
```

### 2. Add fonts

Download and place in `assets/fonts/`:
- `Orbitron.ttf` — https://fonts.google.com/specimen/Orbitron
- `Rajdhani.ttf` — https://fonts.google.com/specimen/Rajdhani

### 3. Run on Android

```bash
npx expo start --android
```

Or scan the QR code in **Expo Go** on your Android device.

---

## 📁 Project Structure

```
nova-ai/
├── app/
│   ├── _layout.jsx        # Root layout + providers
│   ├── index.jsx          # Main chat screen
│   └── settings.jsx       # Settings screen
├── components/
│   ├── NovaOrb.jsx        # Animated orb with rings
│   ├── ChatBubble.jsx     # Neon chat bubbles + streaming
│   └── SidebarDrawer.jsx  # Slide-in history drawer
├── constants/
│   └── theme.js           # Colors, fonts, personalities
├── hooks/
│   └── useAppStore.js     # Global state via React Context
├── assets/
│   └── fonts/             # Orbitron.ttf, Rajdhani.ttf
├── app.json               # Expo config
├── babel.config.js
└── package.json
```

---

## 🎨 Design System

| Token | Value |
|---|---|
| Background | `#030712` |
| Surface | `#0a0f1e` |
| Panel | `#0d1528` |
| Cyan accent | `#00d4ff` |
| Blue | `#0066ff` |
| Purple | `#7c3aed` |
| Green (listen) | `#00ff88` |

---

## 🔌 To Connect Real AI

Replace the `getResponse()` mock in `hooks/useAppStore.js` with an Anthropic API call:

```js
const reply = await fetch('https://api.anthropic.com/v1/messages', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'x-api-key': YOUR_API_KEY,
    'anthropic-version': '2023-06-01',
  },
  body: JSON.stringify({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 1024,
    messages: [{ role: 'user', content: userMessage }],
  }),
}).then(r => r.json());
```

---

**NOVA AI © 2025 · All systems operational**
