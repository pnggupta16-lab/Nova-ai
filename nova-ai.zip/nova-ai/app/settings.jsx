import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  ScrollView, Switch,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { useApp } from '../hooks/useAppStore';
import { Colors, Personalities } from '../constants/theme';

export default function SettingsScreen() {
  const router = useRouter();
  const { personality, setPersonality } = useApp();
  const [voiceReplies, setVoiceReplies] = useState(true);
  const [streamingText, setStreamingText] = useState(true);
  const [autoGreet, setAutoGreet] = useState(true);
  const [soundFX, setSoundFX] = useState(false);

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <Text style={styles.backText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.title}>⚙ SYSTEM CONFIG</Text>
        <View style={{ width: 60 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Personality */}
        <Text style={styles.sectionLabel}>Personality Mode</Text>
        <View style={styles.personalityGrid}>
          {Personalities.map(p => (
            <TouchableOpacity
              key={p.id}
              style={[styles.personalityCard, personality.id === p.id && styles.personalityCardActive]}
              onPress={() => setPersonality(p)}
              activeOpacity={0.7}
            >
              {personality.id === p.id && (
                <LinearGradient
                  colors={['rgba(0,212,255,0.08)', 'transparent']}
                  style={StyleSheet.absoluteFill}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 0, y: 1 }}
                />
              )}
              <Text style={[styles.personalityName, personality.id === p.id && styles.personalityNameActive]}>
                {p.name}
              </Text>
              <Text style={styles.personalityDesc}>{p.desc}</Text>
              {personality.id === p.id && (
                <View style={styles.activeBadge}>
                  <Text style={styles.activeBadgeText}>ACTIVE</Text>
                </View>
              )}
            </TouchableOpacity>
          ))}
        </View>

        {/* Preferences */}
        <Text style={styles.sectionLabel}>Preferences</Text>
        <View style={styles.toggleGroup}>
          {[
            { label: 'Voice Responses', value: voiceReplies, onChange: setVoiceReplies },
            { label: 'Streaming Text', value: streamingText, onChange: setStreamingText },
            { label: 'Auto-Greet on Open', value: autoGreet, onChange: setAutoGreet },
            { label: 'Sound Effects', value: soundFX, onChange: setSoundFX },
          ].map(item => (
            <View key={item.label} style={styles.toggleRow}>
              <Text style={styles.toggleLabel}>{item.label}</Text>
              <Switch
                value={item.value}
                onValueChange={item.onChange}
                trackColor={{ false: Colors.border, true: 'rgba(0,212,255,0.4)' }}
                thumbColor={item.value ? Colors.cyan : Colors.textMuted}
              />
            </View>
          ))}
        </View>

        {/* About */}
        <Text style={styles.sectionLabel}>About</Text>
        <View style={styles.aboutCard}>
          <Text style={styles.aboutTitle}>NOVA AI</Text>
          <Text style={styles.aboutVersion}>Version 4.2.0 — Neural Build</Text>
          <Text style={styles.aboutDesc}>
            NOVA AI is your intelligent Android assistant powered by advanced language models.
            Designed for seamless voice and text interaction with a futuristic cyberpunk experience.
          </Text>
        </View>

        <Text style={styles.footer}>NOVA AI © 2025 · All systems operational</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bg },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
    backgroundColor: Colors.panel,
  },
  backBtn: { paddingVertical: 4, paddingRight: 8 },
  backText: { color: Colors.cyan, fontFamily: 'Rajdhani', fontSize: 15, fontWeight: '600' },
  title: {
    fontFamily: 'Orbitron',
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 2,
    color: Colors.cyan,
  },

  content: { padding: 16, gap: 12, paddingBottom: 40 },

  sectionLabel: {
    fontFamily: 'Rajdhani',
    fontSize: 11,
    color: Colors.textMuted,
    letterSpacing: 2,
    textTransform: 'uppercase',
    marginTop: 8,
    marginBottom: 4,
  },

  personalityGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  personalityCard: {
    width: '47%',
    padding: 14,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 10,
    backgroundColor: Colors.panel,
    overflow: 'hidden',
    gap: 4,
  },
  personalityCardActive: { borderColor: Colors.cyan },
  personalityName: {
    fontFamily: 'Orbitron',
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 1,
    color: Colors.textMuted,
  },
  personalityNameActive: { color: Colors.cyan },
  personalityDesc: {
    fontFamily: 'Rajdhani',
    fontSize: 12,
    color: Colors.textMuted,
    lineHeight: 16,
  },
  activeBadge: {
    marginTop: 6,
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(0,212,255,0.15)',
    borderRadius: 4,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  activeBadgeText: {
    fontFamily: 'Orbitron',
    fontSize: 8,
    color: Colors.cyan,
    letterSpacing: 1,
  },

  toggleGroup: {
    backgroundColor: Colors.panel,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 10,
    overflow: 'hidden',
  },
  toggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  toggleLabel: { fontFamily: 'Rajdhani', fontSize: 15, color: Colors.text, fontWeight: '500' },

  aboutCard: {
    backgroundColor: Colors.panel,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 10,
    padding: 16,
    gap: 6,
  },
  aboutTitle: { fontFamily: 'Orbitron', fontSize: 16, fontWeight: '900', color: Colors.cyan, letterSpacing: 2 },
  aboutVersion: { fontFamily: 'Rajdhani', fontSize: 12, color: Colors.textMuted, letterSpacing: 1 },
  aboutDesc: { fontFamily: 'Rajdhani', fontSize: 13, color: Colors.textMuted, lineHeight: 20, marginTop: 4 },

  footer: {
    fontFamily: 'Rajdhani',
    fontSize: 11,
    color: Colors.textDim,
    textAlign: 'center',
    letterSpacing: 1,
    marginTop: 12,
  },
});
