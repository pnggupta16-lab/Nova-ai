import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  FlatList, KeyboardAvoidingView, Platform, Animated,
  Dimensions, Easing,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import * as Speech from 'expo-speech';
import * as Haptics from 'expo-haptics';
import { useRouter } from 'expo-router';
import { useApp } from '../hooks/useAppStore';
import { Colors } from '../constants/theme';
import NovaOrb from '../components/NovaOrb';
import ChatBubble from '../components/ChatBubble';
import SidebarDrawer from '../components/SidebarDrawer';

const { width } = Dimensions.get('window');

export default function ChatScreen() {
  const router = useRouter();
  const {
    activeSession, activeSessionId, addMessage,
    orbState, setOrbState, getResponse, mode,
  } = useApp();

  const [inputText, setInputText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [hasGreeted, setHasGreeted] = useState(false);
  const flatListRef = useRef(null);

  // Greeting on first load
  useEffect(() => {
    if (!hasGreeted && activeSession?.messages.length === 0) {
      setHasGreeted(true);
      setTimeout(() => bootGreeting(), 800);
    }
  }, [activeSession?.id]);

  const bootGreeting = useCallback(() => {
    setOrbState('speaking');
    const greeting = 'Welcome back. NOVA AI is online.';
    addMessage(activeSessionId, 'nova', greeting);
    Speech.speak(greeting, {
      language: 'en',
      pitch: 0.85,
      rate: 0.9,
      onDone: () => setOrbState('idle'),
    });
  }, [activeSessionId]);

  const sendMessage = useCallback(async () => {
    const text = inputText.trim();
    if (!text) return;
    setInputText('');
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    addMessage(activeSessionId, 'user', text);
    setOrbState('speaking');

    setTimeout(() => {
      const reply = getResponse();
      addMessage(activeSessionId, 'nova', reply);
      Speech.speak(reply, {
        language: 'en',
        pitch: 0.85,
        rate: 0.9,
        onDone: () => setOrbState('idle'),
      });
    }, 600);
  }, [inputText, activeSessionId, getResponse]);

  const toggleMic = useCallback(async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    if (isListening) {
      setIsListening(false);
      setOrbState('idle');
      // Simulate voice-to-text result
      const samples = [
        'What can you tell me about artificial intelligence?',
        'Help me write a Python function.',
        'Explain quantum entanglement simply.',
        'What are the latest tech trends?',
        'Can you help me plan my day?',
      ];
      const recognized = samples[Math.floor(Math.random() * samples.length)];
      setInputText(recognized);
    } else {
      setIsListening(true);
      setOrbState('listening');
      // Auto stop after 3s
      setTimeout(() => {
        setIsListening(false);
        setOrbState('idle');
        const samples = [
          'Tell me about machine learning.',
          'What is the future of AI?',
          'Help me debug my code.',
          'Explain neural networks to me.',
        ];
        const recognized = samples[Math.floor(Math.random() * samples.length)];
        setInputText(recognized);
      }, 3000);
    }
  }, [isListening]);

  useEffect(() => {
    if (activeSession?.messages.length > 0) {
      setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
    }
  }, [activeSession?.messages.length]);

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      {/* Background grid */}
      <View style={styles.grid} pointerEvents="none" />

      {/* Sidebar */}
      <SidebarDrawer open={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={0}
      >
        {/* Top bar */}
        <View style={styles.topbar}>
          <TouchableOpacity style={styles.menuBtn} onPress={() => setSidebarOpen(true)}>
            <Text style={styles.menuIcon}>☰</Text>
          </TouchableOpacity>
          <Text style={styles.topbarTitle}>NOVA</Text>

          {/* Mode tabs */}
          <View style={styles.modeTabs}>
            {['Assist', 'Analyze', 'Create'].map((m, i) => {
              const modes = ['assistant', 'analyst', 'creative'];
              return (
                <TouchableOpacity
                  key={m}
                  style={[styles.modeTab, mode === modes[i] && styles.modeTabActive]}
                  onPress={() => {}}
                >
                  <Text style={[styles.modeTabText, mode === modes[i] && styles.modeTabTextActive]}>
                    {m}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>

          {/* Status */}
          <View style={styles.statusRow}>
            <View style={styles.statusDot} />
            <Text style={styles.statusText}>Online</Text>
          </View>
        </View>

        {/* Orb */}
        <View style={styles.orbSection}>
          <NovaOrb state={orbState} />
          <Text style={[styles.orbLabel, orbState !== 'idle' && styles.orbLabelActive]}>
            {orbState === 'listening' ? 'LISTENING...' :
             orbState === 'speaking' ? 'NOVA SPEAKING' : 'NOVA AI ONLINE'}
          </Text>
        </View>

        {/* Chat */}
        <FlatList
          ref={flatListRef}
          data={activeSession?.messages || []}
          keyExtractor={item => String(item.id)}
          contentContainerStyle={styles.chatContent}
          renderItem={({ item }) => <ChatBubble message={item} />}
          showsVerticalScrollIndicator={false}
          style={styles.chatList}
        />

        {/* Input area */}
        <View style={styles.inputArea}>
          {/* Voice bars */}
          {isListening && <VoiceBars />}

          <View style={styles.inputRow}>
            <TouchableOpacity
              style={[styles.iconBtn, isListening && styles.iconBtnActive]}
              onPress={toggleMic}
              activeOpacity={0.7}
            >
              <Text style={styles.iconBtnText}>🎤</Text>
            </TouchableOpacity>

            <TextInput
              style={styles.textInput}
              value={inputText}
              onChangeText={setInputText}
              placeholder="Message NOVA AI..."
              placeholderTextColor={Colors.textMuted}
              multiline
              maxLength={1000}
              onSubmitEditing={sendMessage}
              blurOnSubmit
            />

            <TouchableOpacity style={styles.sendBtn} onPress={sendMessage} activeOpacity={0.8}>
              <LinearGradient
                colors={[Colors.blue, Colors.cyan]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={styles.sendGradient}
              >
                <Text style={styles.sendIcon}>➤</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

function VoiceBars() {
  const anims = useRef([...Array(9)].map(() => new Animated.Value(0.3))).current;

  useEffect(() => {
    const loops = anims.map((anim, i) =>
      Animated.loop(
        Animated.sequence([
          Animated.timing(anim, {
            toValue: 0.5 + Math.random() * 0.5,
            duration: 300 + i * 80,
            easing: Easing.inOut(Easing.sin),
            useNativeDriver: true,
          }),
          Animated.timing(anim, {
            toValue: 0.3,
            duration: 300 + i * 80,
            easing: Easing.inOut(Easing.sin),
            useNativeDriver: true,
          }),
        ])
      )
    );
    loops.forEach(l => l.start());
    return () => loops.forEach(l => l.stop());
  }, []);

  return (
    <View style={styles.voiceBars}>
      {anims.map((anim, i) => (
        <Animated.View
          key={i}
          style={[styles.voiceBar, { transform: [{ scaleY: anim }] }]}
        />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bg },
  flex: { flex: 1 },
  grid: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.4,
    backgroundColor: 'transparent',
  },

  topbar: {
    height: 52,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
    backgroundColor: Colors.panel,
    gap: 8,
  },
  menuBtn: { padding: 4 },
  menuIcon: { color: Colors.textMuted, fontSize: 20 },
  topbarTitle: {
    fontFamily: 'Orbitron',
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 3,
    color: Colors.cyan,
  },
  modeTabs: { flexDirection: 'row', gap: 4, marginLeft: 4 },
  modeTab: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  modeTabActive: {
    borderColor: Colors.cyan,
    backgroundColor: 'rgba(0,212,255,0.1)',
  },
  modeTabText: { fontSize: 10, color: Colors.textMuted, fontFamily: 'Rajdhani', fontWeight: '600', letterSpacing: 0.5 },
  modeTabTextActive: { color: Colors.cyan },
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: 5, marginLeft: 'auto' },
  statusDot: {
    width: 6, height: 6,
    borderRadius: 3,
    backgroundColor: Colors.green,
  },
  statusText: { fontSize: 10, color: Colors.green, fontFamily: 'Rajdhani', letterSpacing: 1 },

  orbSection: {
    alignItems: 'center',
    paddingVertical: 18,
    gap: 10,
  },
  orbLabel: {
    fontFamily: 'Orbitron',
    fontSize: 10,
    letterSpacing: 3,
    color: Colors.textMuted,
  },
  orbLabelActive: { color: Colors.cyan },

  chatList: { flex: 1 },
  chatContent: { paddingHorizontal: 14, paddingVertical: 8, gap: 10 },

  inputArea: {
    paddingHorizontal: 14,
    paddingTop: 10,
    paddingBottom: 16,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    backgroundColor: Colors.panel,
  },
  voiceBars: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    height: 32,
    gap: 4,
    marginBottom: 10,
  },
  voiceBar: {
    width: 3,
    height: 24,
    backgroundColor: Colors.cyan,
    borderRadius: 2,
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 8,
  },
  iconBtn: {
    width: 44, height: 44,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconBtnActive: {
    borderColor: Colors.green,
    backgroundColor: 'rgba(0,255,136,0.08)',
  },
  iconBtnText: { fontSize: 18 },
  textInput: {
    flex: 1,
    minHeight: 44,
    maxHeight: 110,
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 11,
    color: Colors.text,
    fontFamily: 'Rajdhani',
    fontSize: 15,
  },
  sendBtn: { width: 44, height: 44, borderRadius: 10, overflow: 'hidden' },
  sendGradient: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  sendIcon: { color: '#000', fontSize: 16, fontWeight: '700' },
});
